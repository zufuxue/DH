export const enBase64 = (oldVal: string): string => btoa(encodeURI(oldVal));
