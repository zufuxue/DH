<template>
  <div class="ikun-test-box" style="margin: 8px 0">
    <iframe src="https://www.ikuntest.com" />
  </div>
</template>

<script setup lang="ts"></script>

<style scoped>
.ikun-test-box > iframe {
  border: none;
  height: 640px;
  width: 100%;
  max-width: 420px;
}
</style>
