<template>
  <router-view />
</template>

<script setup lang="ts"></script>

<style>
body {
  margin: 0;
}
</style>
